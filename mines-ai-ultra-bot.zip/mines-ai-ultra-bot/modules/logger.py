def log_info(message): print(f"[INFO] {message}")
def log_error(message): print(f"[ERROR] {message}")
